
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('config.php');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Takes raw data from the request
$json = file_get_contents('php://input');
//$json = '{"pro_name":"Bhavik","product_price":123,"short_desc":"test"}';

// Converts it into a PHP object
$data = json_decode($json,true);

var_dump($data);

$pro_name=$data["pro_name"];
$product_price=$data["product_price"];
$short_desc=$data["short_desc"];

echo $sql = "INSERT INTO add_product(pro_name,product_price,short_desc) VALUES ('$pro_name','$product_price','$short_desc')";

//echo $sql = "INSERT INTO add_product(pro_name,product_price,short_desc) VALUES ('Bhavik',123,'test')";



if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();


?>