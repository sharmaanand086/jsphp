<?php 
session_start();
 $con = mysqli_connect('localhost','root','','cart');
  if(isset($_POST["submit"])){
    $pro_name = $_POST['pro_name'];
    $pr_unit = $_POST['pr_unit'];
     $tax_group = $_POST['tax_group'];
     $comment = $_POST['comment'];    
     $query = "select * from add_product where pro_name ='$pro_name' 
     and product_price ='$pr_unit' and tax_group ='$tax_group'";
    $result = mysqli_query($con,$query);   
    $count = mysqli_num_rows($result);
    if($count>0){
        echo "Already exist";
    }else{
        $sql ="insert into add_product(pro_name,product_price,tax_group,short_desc) 
          values('$pro_name','$pr_unit','$tax_group','$comment')";
     if($con->query($sql)){ 
      $_SESSION["status"]="<h5 class ='text-center'>Successfully Added Product</h5>";   
       header("location:dashboard.php");
     }else{
        echo "no added";
     }
    }
  }

?>