<?php 
session_start();
 $con = mysqli_connect('localhost','root','','cart');  
 for($i=0;$i<=$_POST['number'];$i++){ 
   $sql = "select * from add_package WHERE  p_name='".$_POST['name'][$i]."' and p_rate ='".$_POST['rate'][$i]."'";
   $res_p = mysqli_query($con,$sql);
      if(mysqli_num_rows($res_p)>0){
         $_SESSION['status']="<div class='alert alert-success mt-2'> Already Added</div>";
         header('Location:package.php');
      }else {
         $query = "insert into add_package(p_name,s_desc,p_rate,t_group)
         values('".$_POST['name'][$i]."','".$_POST['s_desc'][$i]."','".$_POST['rate'][$i]."','".$_POST['tax'][$i]."')";
         // var_dump($query);
         $results = mysqli_query($con, $query);
         $_SESSION['success']="<div class='alert alert-success mt-2'>Package Successfully Added</div>";
         header('Location:package.php');   
         
      }  
 }
   
 
?>