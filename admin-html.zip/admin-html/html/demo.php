        <select class="select2 form-select shadow-none mt-3" id="taxrates" name="taxrates[]" multiple="multiple" style="height: 36px; width: 100%" >
                        <optgroup label="Tax Rates">
                           <?php
                              $sql1="SELECT * FROM tax";
                              $result1=$conn->query($sql1);
                              ?>
                           <?php
                              if($result1->num_rows > 0){
                                  while($row1=$result1->fetch_assoc()){
                                      echo '<option value="'.$row1['id'].'">'.$row1['tax_name'].'</option>';
                                  }
                              }
                              ?>
                        </optgroup>
                     </select>