function add_product()
{
	
	var pro_name = document.getElementById("pro_name").value;
	var product_price = document.getElementById("product_price").value;
	var short_desc = document.getElementById("short_desc").value;
	var postData = 
                {
                    "pro_name":pro_name,
                    "product_price":product_price,
                    "short_desc":short_desc
                };
	var settings = {
  "async": false,
  "crossDomain": true,
  "url": "http://localhost/admin-api/add_product.php",
  "method": "POST",
  "headers": {
    "cache-control": "no-cache",
    "Access-Control-Allow-Origin": "https://localhost",
"Access-Control-Allow-Methods": "POST, GET, OPTIONS",
"Access-Control-Allow-Headers": "X-PINGOTHER, Content-Type",
"Access-Control-Max-Age": 86400,
    "postman-token": "f5880ab5-b299-c029-d2ee-760720225f57"
  },
  "data": postData,
  //"data": "{ \n\t\"pro_name\":'"+pro_name+"',\n\t\"product_price\":'"+product_price+"',\n\t\"short_desc\":'"+short_desc+"'}"
}
var jsonData1 = $.ajax(settings).done(function (response) {
 alert(response.trim());
if(response.trim() == '1')
 {
 	localStorage.setItem("error", "Product Added Successfully");
 	window.location.href="product.html";
 } 
else
{
	$('#showerror').show();
}
});
	
}

function view_tax_group()
{
	
	
}

function view_product()
{
	var table;
	$.ajax({
   type:"POST",
   url:"http://localhost/admin-api/view_product.php",
   dataType: 'json',
   success: function(data){
   	console.log(data);
   	for (var i = 0; i < data.length; i++) {
        	

            table += "<tr><td>"+data[i].pro_name+"</td><td>"+data[i].product_price+"</td><td>"+data[i].tax_group+"</td><td>"+data[i].short_desc+"</td><td><button type='submit' name='submit' onclick='update_product(this.id);' style='border:none; background:white;'><i class='bi bi-pencil'></i>Edit</button></td></tr>";
        }
      $('#product').html(table);
    }
	});
}
