
       <?php include 'navbar.php'?>
         
            <?php
            
            $con =mysqli_connect('localhost','root','','cart');
            $pro_id = $_GET['pro_id'];           
            $sql = "select * from add_product where pro_id = '$pro_id'";
            $re = mysqli_query($con,$sql);
            
            $pro_name;
            while ($row=mysqli_fetch_assoc($re)) {
            $pro_id = $row['pro_id'];
            $pro_name = $row['pro_name'];           
            $pr_unit = $row['product_price'];
            $tax_group = $row['tax_group'];
            $comment =$row['short_desc'];
        } 
        
        


?>
      <div class="page-wrapper">         
           <div class="container-fluid" style="height:89vh"> 
           <?php 
          if(isset($_SESSION['update'])){
            echo $_SESSION['update']; 
            unset($_SESSION['update']);
                    }
        ?>  
           <form action ="update_p.php" method = "POST">
          
           <div class = "row">  
                           
                           <div class = "col-sm-6 md-6 col-12">
                           <div class="mb-3">
                               <!-- <label for="exampleInputEmail1" class="form-label" >Product Id</label> -->
                               <input type="hidden" class="form-control" id="disabledInput" name ="pro_id" required value="<?php echo $_GET['pro_id']; ?>" >                    
                             </div>
                           </div>
                           <div class = "col-sm-6 md-6 col-12">
                                        
                       </div>
              <div class = "row">  
                           
                  <div class = "col-sm-6 md-6 col-12">
                  <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Product Name</label>
                      <input type="text" class="form-control" name ="pro_name" required value="<?php echo $pro_name;?>">                    
                    </div>
                  </div>
                  <div class = "col-sm-6 md-6 col-12">
                               
              </div>
              <div class = "row">               
                  <div class = "col-sm-6 md-6 col-12">
                  <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Per Unit Rate</label>
                      <input type="text" class="form-control" 
                      name = "pr_unit"  required value="<?php echo  $pr_unit ?>" >                                            
                    </div>
                  </div>
                  <div class = "col-sm-6 md-6 col-12">         
                  </div>               
              </div>
                <div class = "row">
                <div class = "col-sm-6 md-6 col-12">  
                <div class="mb-3">
                      <label for="floatingSelect">Tax Group</label>                
                      <select class="form-select" name ="tax_group" required value="<?php echo $tax_group ?>">
                     
                        <option value="">Open this select Tax Group</option>
                        
                        <option value="One" <?php
                            if($tax_group == "One"){
                                echo "selected";
                            }
                        ?>>One</option>
                        
                        <option value="Two" <?php
                            if($tax_group == "Two"){
                                echo "selected";
                            }
                        ?>>Two</option>
                        
                         <?php
                            if($tax_group == "Three"){
                                echo "selected";
                            }
                        ?>
                        <option value="Three"   <?php
                            if($tax_group == "Three"){
                                echo "selected";
                            }
                        ?>>Three</option>
                      </select>         
                    
                    </div>       
                  </div>
                  <div class = "col-sm-6 md-6 col-12">         
                  </div>  
                </div>
              <div class = "row">
                <div class = "col-12">
                <div class="mb-3">
                  <div class="form-floating">                   
                      <textarea class="form-control"  name ="comment" 
                        placeholder="Leave a comment here" style="height: 100px"><?php echo $comment ?></textarea> 
                      <label for="floatingTextarea2">Short Description</label>                    
                    </div>
                    <div class ="mt-3">
                       <button type="submit" name="submit" class="btn btn-outline-primary" style= "width:20%"> Update </button>
                    </div>                     
                    </div>
                  </div>  
                </div>
              </div>
            </form>
           
           </div>
    </div>

    </div>
  
    <?php include 'footer.php'?>  
    
    
