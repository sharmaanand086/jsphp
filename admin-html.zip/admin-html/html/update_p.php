  <?php 
      session_start();
      $con = mysqli_connect('localhost','root','','cart');
      if(isset($_POST["submit"])){
          $pro_id = $_POST['pro_id'];
          $pro_name = $_POST['pro_name'];
          $pr_unit = $_POST['pr_unit'];
          $tax_group = $_POST['tax_group'];
          $comment =$_POST['comment'];                
          $sql = "update add_product set pro_name='$pro_name',product_price='$pr_unit',
          tax_group='$tax_group',short_desc ='$comment' where pro_id = '$pro_id'";
          $result = $con->query($sql);                   
  

  if($result)
  {
    $_SESSION ['update'] = "<div class='alert alert-success mt-2'>Package Successfully Added</div>";
       header("location:dashboard.php");     
  }
  else
  {
     echo ' Please Check Your Query ';
      
  }
}
else
{
  header("location:view.php");
}