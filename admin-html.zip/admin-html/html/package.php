<?php session_start(); ?>
<?php include 'navbar.php'?>
<div class="page-wrapper">
<div class="container-fluid" style="height:89vh">
<?php
   if (isset($_SESSION['success'])) {
         echo $_SESSION['success'];
         unset($_SESSION['success']);
   }
   ?>
      <form action ="add_package.php" method ="POST">
         <div class = "row">
            <div class = "col-12 d-flex justify-content-end">              
               <button type="submit" name ="submit" class="btn btn-primary" id ="valid()" style="margin-left:30px">Save</button>
            </div>
         </div>
         <div class = "row">
            <div class ="col-md-12 mt-4">
               <table class="table">
                  <thead>
                     <tr>
                        <th>Package Name</th>
                        <th>Short Description</th>
                        <th>Package Rate</th>
                        <th>Tax Group</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody id="table_body">
                     <tr>
                        <td>     
                        <input type="hidden" id="myInput" name="number">
                     
                           <input type="text" class="form_control" name ="name[]" placeholder="Package Name" required> 
                           <?php
                              if (isset($_SESSION['status'])) {
                                  echo $_SESSION['status'];
                                  unset($_SESSION['status']);
                              }
                        ?>
                        </td>
                        <td>
                           <input type="text" class="form_control" name ="s_desc[]" placeholder="short Description" required >
                        </td>
                        <td>
                           <input type="text" class="form_control" name = "rate[]"placeholder="Package Rate" required >
                        </td>
                        <td>
                           <!-- <input type="text" class="form_control" placeholder="Tax Group" id="txt_group"> -->
                           <select class="form_control" name ="tax[]"   required>
                              <option selected>Select The Tax Group</option>
                              <option>Planning Group</option>
                              <option>Product Group</option>
                              <option>Shipping Group</option>
                              <option>Package Group</option>
                              <p class ="text-danger mt-1" id="txt_group1"></p>
                           </select>
                        </td>
                        <td>
                           <div class="action_container">
                              <!-- <button class="danger"> -->
                              <i class="bi bi-plus-square text-black-50" name ="num" onclick="create_tr('table_body')"></i>
                              <i class="bi bi-trash text-danger"onclick="remove_tr(this)"></i>
                              </button>
                           </div>
                        </td>
                        
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
   </div>
   </form>
</div>
</div>

   
<script>
 
  function create_tr(table_id) {
    let table_body = document.getElementById(table_id),
        first_tr   = table_body.firstElementChild
        tr_clone   = first_tr.cloneNode(true);
      
        $(function() {
         var len = $('.bi.bi-plus-square');
        document.getElementById('myInput').value=len.length;
    
      function hideExceptFirst(selector) {
        var i = 0;
        $(selector).each(function() {
        
          if (i > 0 ) {            
            $(this).hide();
           
          } 
          i++;
        });
      }
      hideExceptFirst('.bi-plus-square');
      
    });
        
       table_body.append(tr_clone);

      clean_first_tr(table_body.firstElementChild);
}

function clean_first_tr(firstTr) {
    let children = firstTr.children;   
    children = Array.isArray(children) ? children : Object.values(children);
    children.forEach(x=>{
        if(x !== firstTr.lastElementChild)
        {
            x.firstElementChild.value = '';
        }
    });
}
function remove_tr(This) {
    if(This.closest('tbody').childElementCount == 1)
    {
        alert("You Don't have Permission to Delete This ?");
    }else{
        This.closest('tr').remove();
        var newval = document.getElementById('myInput').value;
        document.getElementById('myInput').value=(newval-1);
    }
}

</script>
<!-- <script>
  function valid(){
      var name = document.getElementById("p_name").value;
      var dest = document.getElementById("s_dest").value;
      var rate = document.getElementById("p_rate").value;
      var group = document.getElementById("txt_group").value;     
        if(name == ""){
          document.getElementById("p_name1").innerHTML =" ** Please Enter the Package Name";
          return false;
      }else if(dest == "")
      {
        document.getElementById("s_dest1").innerHTML =" ** Please Enter the Short Description";
        return false;
      }
      else if(rate == "")
      {
        document.getElementById("p_rate1").innerHTML =" ** Please Enter the Package Rate";
        return false;
      }
      else if(group == "")
      {
        document.getElementById("txt_group1").innerHTML =" ** Please Enter the Tax Group";
        
        
      }else{
        // window.location.replace("dashboard.php");
      }
      }
  
</script> -->
<?php include 'footer.php'?>