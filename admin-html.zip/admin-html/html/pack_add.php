<?php  
session_start();
 $con = mysqli_connect('localhost','root','','cart');
 for($i=0;$i<=$_POST['number'];$i++){    
    $query = "insert into package(product,pack_name,qty)
    values('".$_POST['Product'][$i]."','".$_POST['Package'][$i]."','".$_POST['qty'][$i]."')";
    $result = mysqli_query($con,$query); 
    $_SESSION['success']="<div class='alert alert-success'>Your product has been  successfully.</div>";   
    header('location:product.php');  
 }

 


?>