<?php 
                 $con = mysqli_connect('localhost','root','','cart');
                    
                        $pro_id = $_GET['pro_id'];                                       
                       ECHO  $sql = "DELETE FROM add_product where pro_id = '$pro_id'";
                        $result = $con->query($sql);                   
  

  if($result)
  {
      header("location:dashboard.php");
  }
  else
  {
      echo ' Please Check Your Query ';
  }


?>