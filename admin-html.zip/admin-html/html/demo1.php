for($i=0;$i<=$_POST['number'];$i++){ 
    $query = "insert into add_package(p_name,p_rate,s_desc,t_group)
      values('".$_POST['name'][$i]."','".$_POST['s_desc'][$i]."','".$_POST['rate'][$i]."','".$_POST['tax'][$i]."')";
   $results = mysqli_query($con, $query);
   var_dump($query);
 }
 <option selected>Select The Product</option>
                              <option value ="Aligner">Aligner</option>
                              <option>Template</option>
                              <option>Retailers</option>
                              <option>Planning</option>
                              <option>Shopping</option>